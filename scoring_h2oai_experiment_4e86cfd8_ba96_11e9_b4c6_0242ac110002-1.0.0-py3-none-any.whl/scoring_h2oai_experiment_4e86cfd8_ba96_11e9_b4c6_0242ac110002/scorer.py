import sys

import os.path
import numpy as np
import pandas as pd
import datatable as dt

from h2oaicore.systemutils import loggererror, loggerinfo, config, loggerdebug, load_obj, load_obj_gz
import h2oaicore.ga_tracker as gt
import h2oaicore.license as lm

from h2oaicore.transformer_utils import fit_transform_batch, prep_test_inplace
from h2oaicore.transformer_utils import preds_columns

# insert custom recipes into global space only for scoring time, could put in each function.
from h2oaicore.auto_dl_support import load_all_custom_recipes
load_all_custom_recipes()

def _load_pickle(d, p):
    path = os.path.join(d, p)
    return load_obj(path)


def _load_pickle_gz(d, p):
    path = os.path.join(d, p)
    return load_obj_gz(path)


def _make_input_frame(columns):
    series = [pd.Series(dtype=c.dtype, name=c.name) for c in columns]
    return pd.concat(series, axis=1)


def _make_bounds_checkers(columns):
    # TODO memoize validations
    checkers = []
    return checkers


def _convert(a):
    return a.item() if isinstance(a, np.generic) else a


def _predict_batch_binary(model):
    def _predict(input_frame, output_margin=False, pred_contribs=False, fast_approx=False):
        kwargs = {'IS_SCORER': True}
        p = model.predict_base(X=input_frame, output_margin=output_margin, pred_contribs=pred_contribs,
                                     fast_approx=fast_approx, **kwargs)
        if not (output_margin or pred_contribs):
            return np.vstack((1 - p, p)).T
        else:
            return p

    return _predict


def _predict_batch_multiclass(model):
    def _predict(input_frame, output_margin=False, pred_contribs=False, fast_approx=False):
        kwargs = {'IS_SCORER': True}
        return model.predict_base(X=input_frame, output_margin=output_margin, pred_contribs=pred_contribs,
                                        fast_approx=fast_approx, **kwargs)

    return _predict


def _predict_batch_regression(model):
    def _predict(input_frame, output_margin=False, pred_contribs=False, fast_approx=False):
        kwargs = {'IS_SCORER': True}
        return model.predict_base(X=input_frame, output_margin=output_margin, pred_contribs=pred_contribs,
                                  fast_approx=fast_approx, **kwargs)

    return _predict


def _predict_binary(predict):
    def _predict(input_frame, output_margin=False, pred_contribs=False, fast_approx=False):
        preds = predict(input_frame, output_margin=output_margin, pred_contribs=pred_contribs, fast_approx=fast_approx)
        if output_margin:
            return [_convert(preds.tolist()[0])]
        else:
            return [_convert(x) for x in preds.tolist()[0]]

    return _predict


def _predict_multiclass(predict):
    def _predict(input_frame, output_margin=False, pred_contribs=False, fast_approx=False):
        preds = predict(input_frame, output_margin=output_margin, pred_contribs=pred_contribs, fast_approx=fast_approx)
        return [_convert(x) for x in preds.tolist()[0]]

    return _predict


def _predict_regression(predict):
    def _predict(input_frame, output_margin=False, pred_contribs=False, fast_approx=False):
        preds = predict(input_frame, output_margin=output_margin, pred_contribs=pred_contribs, fast_approx=fast_approx)
        return [_convert(preds.tolist()[0])]

    return _predict


class Scorer:
    def __init__(self):
        logger = None
        gt.init(logger)
        lm.init(logger)
        if not lm.have_valid_license(short_sleep_on_failure=False):
            loggererror(logger, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            loggererror(logger, "No valid license key found")
            loggererror(logger,
                        "The license can be specified in the following ways:\n"
                        "  * License file in standard location: \n"
                        "    - '~/.driverlessai/license.sig' : file containing the license key\n"
                        "  * Environment variable: \n"
                        "    - 'DRIVERLESS_AI_LICENSE_FILE'  : location of file containing the license key\n"
                        "    - 'DRIVERLESS_AI_LICENSE_KEY'   : license key\n")
            loggererror(logger, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            sys.exit(-1)
        d = os.path.dirname(__file__)
        config_overrides = _load_pickle(d, 'config_overrides.pickle')
        config.update(config_overrides, logger=logger)
        schema = _load_pickle(d, 'schema.pickle')
        model = _load_pickle_gz(d, 'fitted_model.pickle')
        input_columns, input_column_names = zip(*[(c, c.name) for c in schema.columns if c.name != schema.target])
        self._input_columns = input_columns
        self._input_column_names = input_column_names
        # self._transformed_columns = schema.transformed_columns
        self._transformed_columns = model.transformed_features  # more robust, in case models gets slighty
        self._input_frame = _make_input_frame(input_columns)  # Singleton dataframe.
        self._labels = schema.labels
        # self._labels = model.labels
        self._target = schema.target
        self._unfitted_pipeline = _load_pickle(d, 'unfitted_pipeline.pickle')
        self._dtypes = {x.name: x.dtype for x in schema.columns}
        # self._dtypes = model.dtypes
        self._missing_values = schema.missing_values
        loggerdebug(logger, "Scorer model type: %s" % model.__class__.__name__)
        if schema.is_classification:
            if len(self._labels) == 2:
                self._score_batch = _predict_batch_binary(model)
                self._score = _predict_binary(self._score_batch)
            else:
                self._score_batch = _predict_batch_multiclass(model)
                self._score = _predict_multiclass(self._score_batch)
        else:
            self._score_batch = _predict_batch_regression(model)
            self._score = _predict_regression(self._score_batch)

    def _overwrite_input_frame(self, row):
        input_columns = self._input_columns

        if len(input_columns) != len(row):
            raise ValueError('want {} columns in input row, got {}'.format(len(input_columns), len(row)))

        # TODO Add bounds checking
        for i, c in enumerate(input_columns):
            type = self._dtypes[c.name]
            #  fixup missing values here
            if str(row[i]) in self._missing_values:
                value = None if type == "object" else np.nan
            else:
                #  also set the correct type here
                value = np.array([row[i]]).astype("str" if type == "object" else type).tolist()[0]
            self._input_frame.at[0, c.name] = value
        return self._input_frame

    #  TODO: put into pipeline - but too expensive for use inside h2oaicore all the time when unneeded...
    def _fixup_frame(self, frame):
        if isinstance(frame, dt.Frame):
            frame = dt.Frame(frame)  # makes a copy to avoid overwriting original frame
        else:
            frame = pd.DataFrame(frame)  # makes a copy to avoid overwriting original frame
        return prep_test_inplace(frame, self._dtypes, self._missing_values)

    def score(self, row, output_margin=False, pred_contribs=False, fast_approx=False):
        return self._score(self._overwrite_input_frame(row), output_margin=output_margin, pred_contribs=pred_contribs,
                           fast_approx=fast_approx)

    def score_batch(self, input_frame, output_margin=False, pred_contribs=False, fast_approx=False):
        input_frame = self._fixup_frame(input_frame)
        preds = self._score_batch(input_frame, output_margin=output_margin, pred_contribs=pred_contribs,
                                  fast_approx=fast_approx)
        columns = preds_columns(self._target, self._labels, output_margin, self._transformed_columns, pred_contribs)
        return pd.DataFrame(preds, columns=columns)

    def get_target_labels(self):
        return self._labels

    def get_column_names(self):
        return self._input_column_names

    def get_transformed_column_names(self):
        return self._transformed_columns

    def fit_transform_batch(self, train_frame, valid_frame, test_frame=None):
        train_frame = self._fixup_frame(train_frame)
        valid_frame = self._fixup_frame(valid_frame)
        test_frame = self._fixup_frame(test_frame)
        return fit_transform_batch(pipeline=self._unfitted_pipeline,
                                   train_frame=train_frame,
                                   valid_frame=valid_frame,
                                   test_frame=test_frame,
                                   clean_up_children=False)  # normally cannot clean-up children since not in fork

    def get_feature_pipeline(self):
        return self._unfitted_pipeline

    def get_pred_columns(self, output_margin=False, pred_contribs=False):
        return preds_columns(self._target, self._labels, output_margin, self._transformed_columns, pred_contribs)
